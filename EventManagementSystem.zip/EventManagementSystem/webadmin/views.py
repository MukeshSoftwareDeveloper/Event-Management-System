from django.shortcuts import render,redirect
from EventManagementSystem.models import UserProfile
from .models import Events, EventCategory, AdminProfile

# Create your views here.
def home(request):
	uObj = UserProfile.objects.get(user__username=request.user)
	catObj = EventCategory.objects.all()
	eObj = Events.objects.all()
	return render(request, "WelcomeAdmin.html", {'catObjs':catObj ,'eObjs':eObj})

def upload_event(request):
	eCatObj = EventCategory.objects.all()
	if request.method =="POST":
		ename = request.POST['ename']
		disc = request.POST['disc']
		price = request.POST['price']
		img = request.FILES['image']
		eCatid = request.POST['eid']
		#qty = request.POST['qty']

		uObj = UserProfile.objects.get(user__username=request.user)
		eObj = EventCategory.objects.get(id=eCatid)
		eventObj = Events(ename=ename, disc=disc, price=price,image=img, eventCat=eObj, added_by=uObj)
		eventObj.save()
	return render(request, "UploadEvent.html", {'eCatObjs':eCatObj })

def update_event(request,id):
	catObj = EventCategory.objects.all()
	eObj = Events.objects.get(id=id)
	eObj = Events.objects.filter(id=id)

	if request.method =="POST":
		enm = request.POST['ename']
		dic = request.POST['disc']
		prs = request.POST['price']
		img = request.FILES['image']
		#qty = request.POST['qty']

		val = Events.objects.filter(id=id)
		val.update(ename=enm, disc=dic, price=prs)
		return redirect('/webadmin/home/')	
	return render(request, "UpdateEvent.html", {'eCatObjs':catObj,'eObjs':eObj})

def delete_event(request,id):
	eObj = Events.objects.get(id=id)
	eObj.delete()
	return redirect('/webuser/home/')
def event_filter(request, id):
	catObj = EventCategory.objects.all()
	efObj = Events.objects.filter(eventCat_id=id)
	return render(request, "EventListing.html", {'catObjs':catObj,'efObjs':efObj})

def profile(request):
	if request.method =="POST":
		fnm = request.POST['fname']
		lnm = request.POST['lname']
		add1 = request.POST['add1']
		add2 = request.POST['add2']
		lmark = request.POST['lmark']
		city =request.POST['city']
		dist = request.POST['dist']
		state = request.POST['state']
		mob  = request.POST['mobile']
		pcd = request.POST['pincode']

		uObj = UserProfile.objects.get(user__username=request.user)
		prfObj = AdminProfile(fname=fnm, lname=lnm, add_line1=add1, add_line2=add2, landmark=lmark, city=city, dist=dist, state=state,mob=mob, pcd=pcd, user_id=uObj.id)
		prfObj.save()
		return redirect('/webadmin/profile/')
	return render(request, "AdminProfile.html")



