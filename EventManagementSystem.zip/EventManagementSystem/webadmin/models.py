from django.db import models
from EventManagementSystem.models import UserProfile

# Create your models here.
class EventCategory(models.Model):
	catName = models.CharField(max_length=50)

class Events(models.Model):
	ename = models.CharField(max_length=30)
	disc = models.CharField(max_length=30)
	price = models.DecimalField(max_digits=10, decimal_places=3)
	image = models.ImageField(upload_to="eventimage", blank=True)
	qnty = models.IntegerField()
	eventCat = models.ForeignKey(EventCategory, on_delete=models.CASCADE)
	added_by = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
	date = models.DateTimeField(auto_now=True)

class AdminProfile(models.Model):
	fname = models.CharField(max_length=40)
	lname = models.CharField(max_length=40)
	add_line1 = models.CharField(max_length=40)
	add_line2 = models.CharField(max_length=100)
	landmark = models.CharField(max_length=100)
	city = models.CharField(max_length=40)
	dist = models.CharField(max_length=40)
	state = models.CharField(max_length=40)
	mob = models.CharField(max_length=40)
	pcd = models.CharField(max_length=40)
	user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)