from django.contrib import admin
from django.urls import path , include
from . import views

app_name = 'webadmin'

urlpatterns = [
path('home/', views.home),
path('upload_event/', views.upload_event),
path('update_event/<int:id>/', views.update_event, name='update'),
path('delete_event/<int:id>/', views.delete_event, name='delete'),
path('event_filter/<int:id>/', views.event_filter, name='efilter'),
path('profile/', views.profile)

]