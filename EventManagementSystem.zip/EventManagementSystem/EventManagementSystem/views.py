from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from .models import UserProfile
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from webadmin.models import EventCategory, Events

def home(request):
	uObj = UserProfile.objects.get(user__username=request.user)
	catObj = EventCategory.objects.all()
	eObj = Events.objects.all()
	return render(request, "WebMainPage.html", {'catObjs':catObj, 'eObjs':eObj}) 

def registration(request):
	if request.method == "POST":
		fn = request.POST['fname']
		ln = request.POST['lname']
		un = request.POST['uname']
		pwd = request.POST['pwd']
		email = request.POST['email']
		role = request.POST['role']
		mob = request.POST['mob']

		u = User(username=un,password=make_password(pwd),first_name=fn,last_name=ln,email=email)
		u.save()
		uData = UserProfile(user=u, role=role, mobile=mob)
		uData.save()

		return redirect('/registration/')
	return render(request, "SignupPage.html")
 
def login_call(request):
	if request.method =="POST":
		unm = request.POST['uname']
		pwd = request.POST['pwd']
		user = authenticate(username=unm, password=pwd)
		if user:
			login(request, user)
			uObj = UserProfile.objects.get(user__username=request.user)
			try:

				if uObj.role =="admin":
					messages.success(request, "Login Successfully...!!")
					return redirect('/webadmin/home/')
				elif uObj.role =="user":
					messages.success(request, "Login Successfully...!!")
					return redirect('/webuser/home/')
				return render(request, "WebMainPage.html")
			except:
				return HttpResponse("<h2>You Wrong Enter username Or password !!</h2>")
			
			
		else:
			#messages.success(request, "Invalid username Or password !!")
			return HttpResponse("<h2>Invalid username Or password !!</h2>")
	return render(request, "LoginPage.html")

def logout_call(request):
	 logout(request)
	 return redirect('/login/')

def about_us(request):
	return render(request, "About.html")

def contact_us(request):
	return render(request, "Contact.html")

 

