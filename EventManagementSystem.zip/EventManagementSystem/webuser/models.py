from django.db import models
from EventManagementSystem.models import UserProfile
from webadmin.models import Events
from datetime import datetime , date

# Create your models here.
class Cart(models.Model):
	class Meta():
		unique_together = ('event', 'user')

	event = models.ForeignKey(Events,on_delete=models.CASCADE)
	user = models.ForeignKey(UserProfile,on_delete=models.CASCADE)

class ClientProfile(models.Model):
	fname = models.CharField(max_length=40)
	lname = models.CharField(max_length=40)
	add_line1 = models.CharField(max_length=40)
	add_line2 = models.CharField(max_length=100)
	landmark = models.CharField(max_length=100)
	city = models.CharField(max_length=40)
	dist = models.CharField(max_length=40)
	state = models.CharField(max_length=40)
	mob = models.CharField(max_length=40)
	pcd = models.CharField(max_length=40)
	user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)

class OrderDetails(models.Model):
	class Meta():
		unique_together = ('event', 'user')

	cname = models.CharField(max_length=40)
	location = models.CharField(max_length=100)
	date = models.DateField(auto_now_add=False,auto_now=True,blank=False)
	contact =models.IntegerField()
	event = models.ForeignKey(Events,on_delete=models.CASCADE)
	user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)