from django.apps import AppConfig


class WebuserConfig(AppConfig):
    name = 'webuser'
