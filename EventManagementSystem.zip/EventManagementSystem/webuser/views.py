from django.shortcuts import render, redirect
from EventManagementSystem.models import UserProfile
from webadmin.models import EventCategory, Events
from . models import ClientProfile, Cart , OrderDetails
from django.contrib import messages

# Create your views here.
def home(request):
	uObj = UserProfile.objects.get(user__username=request.user)
	eCatObj = EventCategory.objects.all()
	eObj = Events.objects.all()
	cnt = Cart.objects.filter(user_id=uObj.id).count()
	return render(request, "WelcomeUser.html", {'catObjs':eCatObj, 'eObjs':eObj, 'count':cnt})

def book_now(request, id):
	uObj = UserProfile.objects.get(user__username=request.user)
	efObj = Events.objects.filter(id=id)
	
	if request.method =="POST":
		cnm = request.POST['cname']
		loc = request.POST['location']
		dat = request.POST['date']
		cont = request.POST['contact']

		bObj = OrderDetails(cname=cnm, location=loc, date=dat, contact=cont, event=efObj, user=uObj)
		bObj.save()
		messages.success(request, "Event BookNow Successfully...!!")
		return redirect('/webuser/home/')
		# c = Cart(event=efObj, user=uObj)
		# c.save()
		# messages.success(request, "Event BookNow Successfully...!!")
		# return redirect('/webuser/home/')
	return render(request, "BookNow.html", {'efObjs': efObj })
	
def events_filter(request, id):
	catObj = EventCategory.objects.all()
	efObj = Events.objects.filter(eventCat_id=id)
	return render(request, "EventFiltring.html", {'catObjs':catObj,'efObjs':efObj})
	
def my_order(request):
	uObj = UserProfile.objects.get(user__username=request.user)
	# cObj = Cart.objects.all()
	cnt = Cart.objects.filter(user_id=uObj.id).count()
	rdObjs = Cart.objects.filter(user_id=uObj.id)
	 
	items = []
	for i in rdObjs:
		items.append(Events.objects.get(id=i.event_id))
	#print(items)
	return render(request, "MyRecord.html", {'pObjs':items , 'count':cnt})

def customer_reciept(request):
	uObj = UserProfile.objects.get(user__username=request.user)
	cnt = Cart.objects.filter(user_id=uObj.id).count()
	#efObj = Events.objects.filter()
	return render(request, "CustomerReciept.html", {'count':cnt})

def user_profile(request):
	if request.method =="POST":
		fnm = request.POST['fname']
		lnm = request.POST['lname']
		add1 = request.POST['add1']
		add2 = request.POST['add2']
		lmark = request.POST['lmark']
		city =request.POST['city']
		dist = request.POST['dist']
		state = request.POST['state']
		mob  = request.POST['mobile']
		pcd = request.POST['pincode']

		uObj = UserProfile.objects.get(user__username=request.user)
		prfObj = ClientProfile(fname=fnm, lname=lnm, add_line1=add1, add_line2=add2, landmark=lmark, city=city, dist=dist, state=state,mob=mob, pcd=pcd, user_id=uObj.id)
		prfObj.save()
		return redirect('/webuser/user_profile/')
	return render(request, "UserProfile.html")