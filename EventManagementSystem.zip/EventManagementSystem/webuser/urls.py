from django.contrib import admin
from django.urls import path , include
from . import views

app_name = 'webuser'

urlpatterns = [
	path('home/', views.home),
	path('user_profile/', views.user_profile),
	path('book_now/<int:id>/', views.book_now, name='book_event'),
	path('events_filter/<int:id>/', views.events_filter, name='filter'),
	path('my_order/', views.my_order),
	path('customer_reciept/', views.customer_reciept)


]